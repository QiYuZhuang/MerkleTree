package Merkle;

public enum Types {
    Equal,
    Edit,
    Delete,
    Add
}
